function deleteData(req, res) {
  // 削除するIDを取得
  var id = req.query.id;

  var NCMB = require('ncmb');
  var ncmb = new NCMB('0730e01abce99ac3d5400690cb658a25f79e8f0bac8895dd67283e9b98077d1e', 'd4175a28a524d55c47057f6f77b47c0c654842521b94488442867c82deb83dac');

  var Item = ncmb.DataStore('Item');

  Item.equalTo("objectId", id)
      .fetchAll()
      .then(function(results) {
          var promises = [];
          for (var i = 0; i < results.length; i++) {
              var object = results[i];
              // 該当のデータを削除する
              promises.push(object.delete());
          }
          return Promise.all(promises);
      })
      .then(function(result){
          // 成功
          res.send("DELETE data successfully")
       })
       .catch(function(err){
          // 失敗
          res.status(500).send("Error: " + err);
      });
}

module.exports = deleteData;